package LectureComponent;

import StudentComponent.Student;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("43add7e2-2639-42dc-8dc7-674049522c62")
public class LectureGrade {
    @objid ("98015ee5-bcdb-494d-8a81-ad8ad2abd255")
    public Student ;

    @objid ("85039808-5cf7-4d05-baec-bdb604ff6a1c")
    public Lecture ;

}
