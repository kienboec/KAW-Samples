package LectureComponent;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ac3ee73d-1955-41d6-b231-486235302ebe")
public class Lecture {
}
