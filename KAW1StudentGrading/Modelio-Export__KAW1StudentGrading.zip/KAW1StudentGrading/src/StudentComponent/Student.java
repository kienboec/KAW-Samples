package StudentComponent;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9caf087a-fb83-4455-9d40-d5a38200af69")
public class Student {
}
